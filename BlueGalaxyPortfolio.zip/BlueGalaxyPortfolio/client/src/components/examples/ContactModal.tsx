import { useState } from 'react';
import ContactModal from '../ContactModal';
import { Button } from '@/components/ui/button';

export default function ContactModalExample() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="p-8">
      <Button onClick={() => setIsOpen(true)}>Open Contact Modal</Button>
      <ContactModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onGmailClick={() => console.log('Gmail clicked')}
        onWebsiteFormClick={() => console.log('Website form clicked')}
      />
    </div>
  );
}
