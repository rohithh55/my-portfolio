import React, { useState, useEffect } from 'react';
import { Github, Linkedin, Mail, ExternalLink, Download, Menu, X, Cloud, Server, Code, Database, Terminal } from 'lucide-react';

export default function Portfolio() {
  // ==================== EDIT YOUR INFORMATION HERE ====================
  const personalInfo = {
    name: "Rohith Reddy",
    title: "DevOps Engineer",
    location: "Bengaluru, Karnataka",
    email: "rohiithh5@gmail.com",
    phone: "+91 9398431327",
    github: "https://github.com/rohithh5",
    linkedin: "https://www.linkedin.com/in/rohithreddyhh",
    resumeLink: "#", // Add your resume download link here
    
    summary: "DevOps and Cloud enthusiast with hands-on experience in designing scalable cloud infrastructure across AWS. Proficient in containerization, Infrastructure as Code, and CI/CD pipeline implementation. Currently based in Bengaluru, Karnataka.",
    
    aboutMe: [
      "I'm a DevOps Engineer with hands-on experience in designing scalable cloud infrastructure on AWS. Currently working as an AWS DevOps Intern at EdX (Skill Dzire), where I focus on building reliable, observable, and secure cloud-based platforms.",
      "My expertise lies in automating infrastructure provisioning and deployment workflows using Terraform, which has helped reduce manual deployment time by 60%. I'm proficient in containerization with Docker and Kubernetes, and have extensive experience implementing CI/CD pipelines using Jenkins.",
      "I'm passionate about implementing DevOps best practices, optimizing infrastructure reliability, and staying updated with emerging technologies. Currently pursuing my Bachelor's degree in Computer Science from S.K. University, Anantapur (Expected Graduation: April 2025)."
    ],
    
    currentRole: {
      title: "AWS DevOps Intern at EdX (Skill Dzire)",
      duration: "Dec 2024 - Apr 2025"
    }
  };

  const projects = [
    {
      title: "3-Tier Web Application with AWS Infrastructure",
      description: "Complete production-ready 3-tier web architecture deployed on AWS. Built secure, scalable infrastructure using EC2 instances across multiple availability zones with VPC, public/private subnets, Internet Gateway, and NAT Gateway. Automated entire infrastructure provisioning using Terraform with modular design and DRY principles. Implemented comprehensive security with Security Groups, IAM roles, and network isolation following AWS best practices.",
      tech: ["AWS EC2", "VPC", "Terraform", "Jenkins", "Docker", "Security Groups", "IAM"],
      github: "https://github.com/rohithh55/aws-infrastructure.git",
      demo: "#",
      image: "🏗️"
    },
    {
      title: "Login Application v2 - Full Stack Authentication",
      description: "Modern full-stack login application with secure authentication system. Implemented user registration, login, and session management with encrypted password storage. Built with containerization support using Docker for consistent deployment across environments. Features responsive UI design, form validation, and secure backend API endpoints. Includes CI/CD pipeline setup for automated testing and deployment.",
      tech: ["Docker", "Node.js", "Authentication", "CI/CD", "REST API", "Security"],
      github: "https://github.com/rohithh55/loginappv2.git",
      demo: "#",
      image: "🔐"
    }
  ];

  const skills = {
    "Cloud Platforms": ["AWS EC2", "AWS S3", "AWS VPC", "AWS IAM", "AWS RDS", "AWS Lambda", "AWS EKS"],
    "Infrastructure as Code": ["Terraform", "Ansible"],
    "Container & Orchestration": ["Docker", "Kubernetes", "AWS EKS"],
    "CI/CD Tools": ["Jenkins"],
    "Monitoring & Observability": ["Prometheus", "Grafana", "CloudWatch"],
    "Version Control": ["Git", "GitHub"],
    "Programming & Scripting": ["Python", "Bash", "YAML", "Linux Shell Scripting"],
    "Networking": ["VPC", "Subnets", "Route Tables", "Security Groups", "Load Balancers", "NAT Gateway"]
  };

  const devOpsPractices = [
    "Continuous Integration",
    "Continuous Deployment",
    "Automation",
    "Infrastructure Monitoring",
    "Scalability",
    "High Availability"
  ];
  // ==================== END OF EDITABLE SECTION ====================

  const [activeSection, setActiveSection] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [showContactModal, setShowContactModal] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
      setIsMenuOpen(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Message sent! (This is a demo)');
    setFormData({ name: '', email: '', subject: '', message: '' });
    setShowContactModal(false);
  };

  const handleSendMessage = () => {
    setShowContactModal(true);
  };

  const handleGmailOption = () => {
    window.location.href = `mailto:${personalInfo.email}`;
    setShowContactModal(false);
  };

  const handleWebsiteChat = () => {
    setShowContactModal(false);
    scrollToSection('contact');
  };

  const projects = [
    {
      title: "3-Tier Web Application with AWS Infrastructure",
      description: "Complete production-ready 3-tier web architecture deployed on AWS. Built secure, scalable infrastructure using EC2 instances across multiple availability zones with VPC, public/private subnets, Internet Gateway, and NAT Gateway. Automated entire infrastructure provisioning using Terraform with modular design and DRY principles. Implemented comprehensive security with Security Groups, IAM roles, and network isolation following AWS best practices.",
      tech: ["AWS EC2", "VPC", "Terraform", "Jenkins", "Docker", "Security Groups", "IAM"],
      github: "https://github.com/rohithh55/aws-infrastructure.git",
      demo: "#",
      image: "🏗️"
    },
    {
      title: "Login Application v2 - Full Stack Authentication",
      description: "Modern full-stack login application with secure authentication system. Implemented user registration, login, and session management with encrypted password storage. Built with containerization support using Docker for consistent deployment across environments. Features responsive UI design, form validation, and secure backend API endpoints. Includes CI/CD pipeline setup for automated testing and deployment.",
      tech: ["Docker", "Node.js", "Authentication", "CI/CD", "REST API", "Security"],
      github: "https://github.com/rohithh55/loginappv2.git",
      demo: "#",
      image: "🔐"
    }
  ];

  const skills = {
    "Cloud Platforms": ["AWS EC2", "AWS S3", "AWS VPC", "AWS IAM", "AWS RDS", "AWS Lambda", "AWS EKS"],
    "Infrastructure as Code": ["Terraform", "Ansible"],
    "Container & Orchestration": ["Docker", "Kubernetes", "AWS EKS"],
    "CI/CD Tools": ["Jenkins"],
    "Monitoring & Observability": ["Prometheus", "Grafana", "CloudWatch"],
    "Version Control": ["Git", "GitHub"],
    "Programming & Scripting": ["Python", "Bash", "YAML", "Linux Shell Scripting"],
    "Networking": ["VPC", "Subnets", "Route Tables", "Security Groups", "Load Balancers", "NAT Gateway"]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      {/* Contact Modal */}
      {showContactModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl p-8 max-w-md w-full border border-blue-500/30">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-blue-400">Contact Me</h3>
              <button onClick={() => setShowContactModal(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <p className="text-gray-300 mb-6">Choose how you'd like to get in touch:</p>
            <div className="space-y-4">
              <button
                onClick={handleGmailOption}
                className="w-full bg-blue-600 hover:bg-blue-700 p-4 rounded-lg transition-all flex items-center space-x-4"
              >
                <Mail size={24} className="text-white" />
                <div className="text-left">
                  <div className="font-semibold">Email via Gmail</div>
                  <div className="text-sm text-blue-200">Opens your email client</div>
                </div>
              </button>
              <button
                onClick={handleWebsiteChat}
                className="w-full bg-cyan-600 hover:bg-cyan-700 p-4 rounded-lg transition-all flex items-center space-x-4"
              >
                <Terminal size={24} className="text-white" />
                <div className="text-left">
                  <div className="font-semibold">Message from Website</div>
                  <div className="text-sm text-cyan-200">Use contact form below</div>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-slate-900/95 backdrop-blur-sm shadow-lg' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              {personalInfo.name.toUpperCase()}
            </div>
            
            <div className="hidden md:flex space-x-8">
              {['home', 'about', 'projects', 'skills', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className={`capitalize hover:text-blue-400 transition-colors ${activeSection === item ? 'text-blue-400' : ''}`}
                >
                  {item}
                </button>
              ))}
            </div>

            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-slate-900/95 backdrop-blur-sm">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {['home', 'about', 'projects', 'skills', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="block w-full text-left px-3 py-2 capitalize hover:bg-blue-900/50 rounded"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center px-4 pt-16">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-5xl md:text-7xl font-bold">
              Hi, I'm <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">{personalInfo.name}</span>
            </h1>
            <h2 className="text-2xl md:text-3xl text-blue-300">{personalInfo.title}</h2>
            <p className="text-lg text-gray-300">
              {personalInfo.summary}
            </p>
            <div className="flex space-x-4">
              <a href={personalInfo.github} target="_blank" rel="noopener noreferrer" className="p-3 bg-blue-600 hover:bg-blue-700 rounded-full transition-colors">
                <Github size={24} />
              </a>
              <a href={personalInfo.linkedin} target="_blank" rel="noopener noreferrer" className="p-3 bg-blue-600 hover:bg-blue-700 rounded-full transition-colors">
                <Linkedin size={24} />
              </a>
              <a href={`mailto:${personalInfo.email}`} className="p-3 bg-blue-600 hover:bg-blue-700 rounded-full transition-colors">
                <Mail size={24} />
              </a>
            </div>
            <div className="flex flex-wrap gap-4">
              <button onClick={() => scrollToSection('projects')} className="flex items-center space-x-2 bg-cyan-600 hover:bg-cyan-700 px-6 py-3 rounded-lg transition-colors">
                <Code size={20} />
                <span>View My Projects</span>
              </button>
              <button onClick={handleSendMessage} className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg transition-colors">
                <Mail size={20} />
                <span>Send a Message</span>
              </button>
            </div>
            <a href={personalInfo.resumeLink} className="flex items-center space-x-2 bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-lg transition-colors w-fit">
              <Download size={20} />
              <span>Download Resume</span>
            </a>
          </div>
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-64 h-64 md:w-80 md:h-80 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full opacity-20 absolute animate-pulse"></div>
              <div className="w-64 h-64 md:w-80 md:h-80 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-full flex items-center justify-center relative">
                <Cloud size={120} className="text-white" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="min-h-screen flex items-center justify-center px-4 py-20">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
            About <span className="text-blue-400">Me</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              {personalInfo.aboutMe.map((paragraph, idx) => (
                <p key={idx} className="text-lg text-gray-300">{paragraph}</p>
              ))}
              <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
                <h3 className="font-semibold text-blue-400 mb-2">Current Role</h3>
                <p className="text-sm text-gray-300">{personalInfo.currentRole.title}</p>
                <p className="text-xs text-gray-400">{personalInfo.currentRole.duration}</p>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 p-8 rounded-2xl backdrop-blur-sm">
                <div className="w-80 h-80 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-lg flex items-center justify-center">
                  <span className="text-8xl">👨‍💻</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="min-h-screen flex items-center justify-center px-4 py-20">
        <div className="max-w-7xl mx-auto w-full">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
            Featured <span className="text-blue-400">Projects</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, idx) => (
              <div key={idx} className="bg-blue-900/20 backdrop-blur-sm p-8 rounded-xl border border-blue-500/20 hover:border-blue-500/50 transition-all hover:transform hover:scale-105">
                <div className="flex items-center justify-center mb-6">
                  <div className="w-32 h-32 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl flex items-center justify-center text-6xl">
                    {project.image}
                  </div>
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-blue-300">{project.title}</h3>
                <p className="text-gray-400 mb-6 leading-relaxed">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tech.map((tech) => (
                    <span key={tech} className="bg-blue-600/30 px-3 py-1 rounded-full text-xs">
                      {tech}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-4">
                  <a href={project.github} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors">
                    <Github size={18} />
                    <span>View Code</span>
                  </a>
                  {project.demo !== "#" && (
                    <a href={project.demo} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 bg-cyan-600 hover:bg-cyan-700 px-4 py-2 rounded-lg transition-colors">
                      <ExternalLink size={18} />
                      <span>Live Demo</span>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="min-h-screen flex items-center justify-center px-4 py-20">
        <div className="max-w-7xl mx-auto w-full">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
            Professional <span className="text-blue-400">Skills</span>
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Object.entries(skills).map(([category, items]) => (
              <div key={category} className="bg-blue-900/20 backdrop-blur-sm p-6 rounded-xl border border-blue-500/20 hover:border-blue-500/50 transition-all">
                <h3 className="text-xl font-semibold mb-4 text-blue-400">{category}</h3>
                <div className="flex flex-wrap gap-2">
                  {items.map((skill) => (
                    <span key={skill} className="bg-blue-600/30 px-3 py-1 rounded-full text-sm hover:bg-blue-600/50 transition-colors">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-12 bg-blue-900/20 backdrop-blur-sm p-6 rounded-xl border border-blue-500/20">
            <h3 className="text-2xl font-semibold mb-4 text-blue-400">DevOps Practices</h3>
            <div className="flex flex-wrap gap-3">
              {devOpsPractices.map((practice) => (
                <span key={practice} className="bg-blue-600/30 px-4 py-2 rounded-lg text-sm hover:bg-blue-600/50 transition-colors">
                  {practice}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="min-h-screen flex items-center justify-center px-4 py-20">
        <div className="max-w-4xl mx-auto w-full">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
            Get In <span className="text-blue-400">Touch</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div className="bg-blue-900/20 backdrop-blur-sm p-6 rounded-xl border border-blue-500/20">
              <Mail className="text-blue-400 mb-3" size={32} />
              <h3 className="text-xl font-semibold mb-2">Email</h3>
              <a href={`mailto:${personalInfo.email}`} className="text-blue-300 hover:text-blue-200">{personalInfo.email}</a>
            </div>
            <div className="bg-blue-900/20 backdrop-blur-sm p-6 rounded-xl border border-blue-500/20">
              <Terminal className="text-blue-400 mb-3" size={32} />
              <h3 className="text-xl font-semibold mb-2">Phone</h3>
              <a href={`tel:${personalInfo.phone}`} className="text-blue-300 hover:text-blue-200">{personalInfo.phone}</a>
            </div>
          </div>
          <div className="bg-blue-900/20 backdrop-blur-sm p-8 rounded-xl border border-blue-500/20">
            <h3 className="text-2xl font-semibold mb-6 text-center">Send Me a Message</h3>
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <input
                  type="text"
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="bg-slate-800 border border-blue-500/30 rounded-lg px-4 py-3 w-full focus:outline-none focus:border-blue-500"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="bg-slate-800 border border-blue-500/30 rounded-lg px-4 py-3 w-full focus:outline-none focus:border-blue-500"
                />
              </div>
              <input
                type="text"
                placeholder="Subject"
                value={formData.subject}
                onChange={(e) => setFormData({...formData, subject: e.target.value})}
                className="bg-slate-800 border border-blue-500/30 rounded-lg px-4 py-3 w-full focus:outline-none focus:border-blue-500"
              />
              <textarea
                rows={6}
                placeholder="Your Message"
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="bg-slate-800 border border-blue-500/30 rounded-lg px-4 py-3 w-full focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={handleSubmit}
                className="bg-blue-600 hover:bg-blue-700 px-8 py-3 rounded-lg w-full transition-colors"
              >
                Send Message
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 py-8 px-4">
        <div className="max-w-7xl mx-auto text-center space-y-2">
          <p className="text-gray-400">© 2024 {personalInfo.name} - {personalInfo.title} Portfolio</p>
          <p className="text-gray-500 text-sm">{personalInfo.location} | Designed & Built with ❤️</p>
        </div>
      </footer>
    </div>
  );
}