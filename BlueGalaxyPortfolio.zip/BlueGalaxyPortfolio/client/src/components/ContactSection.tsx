import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, Phone, MapPin } from 'lucide-react';
import ContactModal from './ContactModal';

export default function ContactSection() {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Message sent! (Demo)');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const handleGmailOption = () => {
    window.location.href = 'mailto:rohiithh5@gmail.com';
    setShowModal(false);
  };

  const handleWebsiteChat = () => {
    setShowModal(false);
  };

  return (
    <section id="contact" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-7xl mx-auto w-full">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-4 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
          Get In Touch
        </h2>
        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          Have a project in mind or want to discuss DevOps opportunities? Let's connect!
        </p>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="bg-card/40 backdrop-blur-sm border-card-border p-6 sm:p-8">
            <h3 className="text-2xl font-bold text-cyan-400 mb-6">Send a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-background/50 border-border"
                  data-testid="input-name"
                />
              </div>
              <div>
                <Input
                  type="email"
                  placeholder="Your Email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-background/50 border-border"
                  data-testid="input-email"
                />
              </div>
              <div>
                <Input
                  placeholder="Subject"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="bg-background/50 border-border"
                  data-testid="input-subject"
                />
              </div>
              <div>
                <Textarea
                  placeholder="Your Message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="bg-background/50 border-border min-h-32"
                  data-testid="input-message"
                />
              </div>
              <Button type="submit" className="w-full" data-testid="button-send">
                Send Message
              </Button>
            </form>
          </Card>

          <div className="space-y-6">
            <Card className="bg-card/40 backdrop-blur-sm border-card-border p-6 hover-elevate transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary/20 rounded-lg">
                  <Mail size={24} className="text-cyan-400" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-1">Email</h4>
                  <p className="text-muted-foreground" data-testid="text-email">rohiithh5@gmail.com</p>
                </div>
              </div>
            </Card>

            <Card className="bg-card/40 backdrop-blur-sm border-card-border p-6 hover-elevate transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary/20 rounded-lg">
                  <Phone size={24} className="text-cyan-400" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-1">Phone</h4>
                  <p className="text-muted-foreground" data-testid="text-phone">+91 9398431327</p>
                </div>
              </div>
            </Card>

            <Card className="bg-card/40 backdrop-blur-sm border-card-border p-6 hover-elevate transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary/20 rounded-lg">
                  <MapPin size={24} className="text-cyan-400" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-1">Location</h4>
                  <p className="text-muted-foreground" data-testid="text-location">Bengaluru, Karnataka</p>
                </div>
              </div>
            </Card>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => setShowModal(true)}
              data-testid="button-contact-options"
            >
              View Contact Options
            </Button>
          </div>
        </div>
      </div>

      <ContactModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onGmailClick={handleGmailOption}
        onWebsiteFormClick={handleWebsiteChat}
      />
    </section>
  );
}
