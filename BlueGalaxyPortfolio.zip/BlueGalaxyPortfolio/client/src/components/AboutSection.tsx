import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import aboutImage from '@assets/generated_images/Coding_terminal_about_section_7bda59ce.png';

export default function AboutSection() {
  const aboutParagraphs = [
    "I'm a DevOps Engineer with hands-on experience in designing scalable cloud infrastructure on AWS. Currently working as an AWS DevOps Intern at Acenar Technologies Pvt Ltd, where I focus on building reliable, observable, and secure cloud-based platforms.",
    "My expertise lies in automating infrastructure provisioning and deployment workflows using Terraform, which has helped reduce manual deployment time by 60%. I'm proficient in containerization with Docker and Kubernetes, and have extensive experience implementing CI/CD pipelines using Jenkins and GitHub Actions.",
    "I'm passionate about implementing DevOps best practices, optimizing infrastructure reliability, and staying updated with emerging technologies. Completed my Bachelor's degree in Computer Science from S.K. University, Anantapur (Graduated: April 2025, CGPA: 7.2/10).",
  ];

  return (
    <section id="about" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-7xl mx-auto w-full">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-12 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
          About Me
        </h2>

        <div className="grid md:grid-cols-5 gap-8 items-center">
          <div className="md:col-span-3 space-y-6">
            <Card className="bg-card/50 backdrop-blur-sm border-card-border p-6 sm:p-8">
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-1 w-12 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full" />
                  <h3 className="text-xl font-semibold text-cyan-400">Current Role</h3>
                </div>
                <div>
                  <p className="text-lg font-medium text-foreground">AWS DevOps Intern at Acenar Technologies Pvt Ltd</p>
                  <p className="text-sm text-muted-foreground">Dec 2024 - Jul 2025</p>
                </div>
              </div>
            </Card>

            {aboutParagraphs.map((paragraph, index) => (
              <Card key={index} className="bg-card/30 backdrop-blur-sm border-card-border p-6">
                <p className="text-base text-card-foreground leading-relaxed">{paragraph}</p>
              </Card>
            ))}

            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="bg-accent/20 text-accent-foreground border-accent/30">
                Cloud Infrastructure
              </Badge>
              <Badge variant="secondary" className="bg-accent/20 text-accent-foreground border-accent/30">
                Automation
              </Badge>
              <Badge variant="secondary" className="bg-accent/20 text-accent-foreground border-accent/30">
                DevOps Practices
              </Badge>
            </div>
          </div>

          <div className="md:col-span-2 flex justify-center">
            <img
              src={aboutImage}
              alt="Coding Terminal"
              className="w-full max-w-md animate-float-slow drop-shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
