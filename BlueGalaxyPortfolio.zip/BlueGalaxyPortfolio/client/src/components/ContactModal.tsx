import { Mail, Terminal, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGmailClick: () => void;
  onWebsiteFormClick: () => void;
}

export default function ContactModal({ isOpen, onClose, onGmailClick, onWebsiteFormClick }: ContactModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <Card className="bg-card border-card-border p-8 max-w-md w-full">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-cyan-400">Contact Me</h3>
          <Button size="icon" variant="ghost" onClick={onClose} data-testid="button-close-modal">
            <X size={24} />
          </Button>
        </div>
        
        <p className="text-muted-foreground mb-6">Choose how you'd like to get in touch:</p>
        
        <div className="space-y-4">
          <button
            onClick={onGmailClick}
            className="w-full bg-primary hover-elevate active-elevate-2 p-4 rounded-lg transition-all flex items-center gap-4"
            data-testid="button-gmail-option"
          >
            <Mail size={24} className="text-primary-foreground" />
            <div className="text-left">
              <div className="font-semibold text-primary-foreground">Email via Gmail</div>
              <div className="text-sm text-primary-foreground/80">Opens your email client</div>
            </div>
          </button>
          
          <button
            onClick={onWebsiteFormClick}
            className="w-full bg-accent hover-elevate active-elevate-2 p-4 rounded-lg transition-all flex items-center gap-4"
            data-testid="button-website-form"
          >
            <Terminal size={24} className="text-accent-foreground" />
            <div className="text-left">
              <div className="font-semibold text-accent-foreground">Message from Website</div>
              <div className="text-sm text-accent-foreground/80">Use contact form below</div>
            </div>
          </button>
        </div>
      </Card>
    </div>
  );
}
