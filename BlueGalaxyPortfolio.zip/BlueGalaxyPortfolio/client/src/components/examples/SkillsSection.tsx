import SkillsSection from '../SkillsSection';

export default function SkillsSectionExample() {
  return <SkillsSection />;
}
