import GalaxyBackground from '../GalaxyBackground';

export default function GalaxyBackgroundExample() {
  return (
    <div className="relative h-screen w-full">
      <GalaxyBackground />
      <div className="relative z-10 flex items-center justify-center h-full">
        <h1 className="text-4xl font-bold text-cyan-400">Galaxy Background Demo</h1>
      </div>
    </div>
  );
}
