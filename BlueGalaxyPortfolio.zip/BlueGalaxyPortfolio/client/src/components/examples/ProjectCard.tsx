import ProjectCard from '../ProjectCard';

export default function ProjectCardExample() {
  return (
    <div className="p-8 max-w-md">
      <ProjectCard
        title="3-Tier Web Application"
        description="Complete production-ready architecture deployed on AWS with secure infrastructure using EC2, VPC, and automated provisioning with Terraform."
        tech={['AWS EC2', 'VPC', 'Terraform', 'Docker']}
        github="https://github.com/rohithh55/aws-infrastructure.git"
        demo="#"
        icon="🏗️"
      />
    </div>
  );
}
