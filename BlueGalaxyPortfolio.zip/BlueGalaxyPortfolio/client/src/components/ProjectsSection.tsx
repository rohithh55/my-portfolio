import ProjectCard from './ProjectCard';

const projects = [
  {
    title: '3-Tier Web Application with AWS Infrastructure',
    description:
      'Complete production-ready 3-tier web architecture deployed on AWS. Built secure, scalable infrastructure using EC2 instances across multiple availability zones with VPC, public/private subnets, Internet Gateway, and NAT Gateway. Automated entire infrastructure provisioning using Terraform with modular design and DRY principles.',
    tech: ['AWS EC2', 'VPC', 'Terraform', 'Jenkins', 'Docker', 'Security Groups', 'IAM'],
    github: 'https://github.com/rohithh55/aws-infrastructure.git',
    demo: '#',
    icon: '🏗️',
  },
  {
    title: 'Login Application v2 - Full Stack Authentication',
    description:
      'Modern full-stack login application with secure authentication system. Implemented user registration, login, and session management with encrypted password storage. Built with containerization support using Docker for consistent deployment across environments. Features responsive UI design, form validation, and secure backend API endpoints.',
    tech: ['Docker', 'Node.js', 'Authentication', 'CI/CD', 'REST API', 'Security'],
    github: 'https://github.com/rohithh55/loginappv2.git',
    demo: '#',
    icon: '🔐',
  },
];

export default function ProjectsSection() {
  return (
    <section id="projects" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-7xl mx-auto w-full">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-4 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
          Featured Projects
        </h2>
        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          Explore my recent work in cloud infrastructure, DevOps automation, and full-stack development
        </p>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} {...project} />
          ))}
        </div>
      </div>
    </section>
  );
}
