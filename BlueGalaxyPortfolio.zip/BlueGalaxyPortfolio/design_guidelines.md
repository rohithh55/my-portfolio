# Design Guidelines: Blue Galaxy DevOps Portfolio

## Design Approach
**Reference-Based Design** inspired by Soumyajit Portfolio with blue galaxy aesthetic transformation. This portfolio prioritizes visual impact and smooth animations to create an immersive, cosmic-themed professional showcase.

## Core Visual Theme
Transform the purple/violet Soumyajit theme into a **blue galaxy aesthetic** with:
- Deep space background: Dark navy to midnight blue gradients (slate-900, blue-950, indigo-950)
- Accent colors: Bright cyan and electric blue for highlights (cyan-400, blue-400, sky-500)
- Glassmorphism effects with blue-tinted transparency
- Animated particle system creating a starfield effect throughout

## Typography System
- **Headings**: Bold, modern sans-serif (Inter or similar) 
  - H1: 4xl to 7xl, bold weight, gradient text from blue-400 to cyan-400
  - H2: 3xl to 5xl, semibold
  - H3: 2xl to 3xl, medium weight
- **Body**: 16-18px base, regular weight, light gray (gray-300)
- **Accent text**: Cyan-400 for role titles, tech tags, and highlights
- Use text-shadow for glowing effects on important headings

## Layout System
**Spacing**: Tailwind units of 4, 8, 12, 16, 20, 24, 32 for consistent rhythm
- Section padding: py-20 to py-32 on desktop, py-12 to py-16 on mobile
- Container: max-w-7xl centered with px-4 to px-8
- Component spacing: gap-8 to gap-12 for cards and grids

## Component Library

### Navigation
- Fixed transparent nav becoming frosted glass (bg-slate-900/80 backdrop-blur-md) on scroll
- Logo with blue-to-cyan gradient text effect
- Desktop: Horizontal menu with hover underline animations in cyan-400
- Mobile: Slide-in hamburger menu with backdrop blur
- Height: h-16 to h-20

### Hero Section (Full Viewport)
- Grid layout: 2-column on desktop (text left, illustration right)
- Animated typing effect for role: "DevOps Engineer | Cloud Architect | Automation Specialist"
- Large gradient heading with name in blue-to-cyan
- Particle background with floating stars and nebula effects
- Social icons (GitHub, LinkedIn, Email) in circular blue-600 buttons with hover glow
- CTA buttons: "Download Resume" (filled blue-600) and "View Projects" (outlined cyan-400)

### About Section
- 2-column grid: Text content (60%) + animated illustration/graphic (40%)
- Card-based layout with glassmorphic container (bg-slate-800/50 border-blue-500/30)
- Current role highlight card with blue-600 accent border
- Paragraph text in readable chunks (max-w-3xl)
- Subtle floating animation on illustration

### Projects Showcase
- Grid: 1 column mobile, 2 columns tablet/desktop
- Project cards with:
  - Emoji icon (large, top-left)
  - Title in bold cyan-400
  - Description in gray-300
  - Tech stack badges: Rounded pills with blue-900/50 background, cyan-400 text, border-blue-500/30
  - Footer with GitHub and Demo links as icon buttons
  - Hover: Lift effect (translate-y-[-4px]) with blue glow shadow
  - Card styling: bg-slate-800/60 border-blue-500/20 rounded-xl p-6

### Skills Section
- Category-based organization (Cloud, IaC, CI/CD, etc.)
- Each category in glassmorphic card
- Skills as badges: bg-blue-600/20 text-cyan-300 px-4 py-2 rounded-lg
- Grid layout for badges: grid-cols-2 md:grid-cols-3 gap-3
- DevOps practices as highlighted pills with icons

### Contact Section
- 2-column layout: Contact form (left) + Contact info cards (right)
- Modal system for contact options (Gmail vs Website form)
- Form inputs: bg-slate-800/50 border-blue-500/30 focus:border-cyan-400 rounded-lg
- Submit button: Full-width blue-600 with glow effect
- Contact info cards with icons (Mail, Terminal) and descriptions

### Footer
- Simple centered layout with social links
- Copyright text in gray-500
- Background: bg-slate-900/80

## Animations & Effects

### Background
- Animated particle system (canvas-based or CSS-animated divs)
- Floating stars of varying sizes and opacity
- Subtle blue nebula clouds with slow drift animation
- Radial gradients creating depth

### Component Animations
- Fade-in on scroll for sections (intersection observer)
- Typing animation for hero tagline (character-by-character reveal)
- Smooth scroll behavior for navigation links
- Card hover: Scale 1.02, translate-y-[-4px], blue glow box-shadow
- Button hover: Brightness increase, scale 1.05
- Icon hover: Rotate or bounce micro-interactions
- Modal: Backdrop blur-sm with scale-in animation

### Transitions
All transitions: transition-all duration-300 ease-in-out

## Responsive Breakpoints
- Mobile: < 768px (single column, stacked layout)
- Tablet: 768px - 1024px (2-column grids)
- Desktop: > 1024px (full multi-column layouts)

## Images Section

### Hero Illustration (Right Side)
- DevOps-themed SVG illustration or graphic showing:
  - Cloud infrastructure elements
  - Interconnected nodes/servers
  - Blue/cyan color scheme matching theme
  - Animated subtle floating or rotating effect
- Alternative: Abstract geometric shapes representing automation/pipelines
- Placement: Right 40% of hero section, centered vertically

### About Section Graphic
- Professional avatar or abstract representation
- Coding/terminal-themed illustration in blue tones
- Floating animation (2-3 second loop, gentle up-down movement)
- Placement: Right side of about section, max-w-md

### Decorative Elements
- Small particle/star elements scattered throughout
- Gradient orbs in background for depth (blur-3xl opacity-20)
- Blue glow effects behind key sections

## Accessibility Notes
- Maintain WCAG AA contrast ratios (white/cyan text on dark backgrounds)
- Focus states: Blue-400 ring with ring-offset-2
- Keyboard navigation support for all interactive elements
- Alt text for all illustrations

## Key Design Principles
1. **Cosmic Immersion**: Galaxy background present on all sections with consistent particle effects
2. **Blue Hierarchy**: Primary blue-600, accents cyan-400/sky-500, backgrounds slate-900/800
3. **Glassmorphism**: Frosted glass cards with blue-tinted borders throughout
4. **Smooth Motion**: All animations should feel fluid and purposeful, not distracting
5. **Professional + Creative**: Balance technical credibility with visual creativity

This creates a comprehensive, visually striking DevOps portfolio that stands out while maintaining professionalism through the galaxy theme transformation.