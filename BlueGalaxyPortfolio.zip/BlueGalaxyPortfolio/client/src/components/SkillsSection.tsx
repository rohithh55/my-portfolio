import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Cloud, Server, Code, Database, Terminal, GitBranch } from 'lucide-react';

const skillCategories = [
  {
    title: 'Cloud Platforms',
    icon: Cloud,
    skills: ['AWS EC2', 'AWS S3', 'AWS VPC', 'AWS IAM', 'AWS RDS', 'AWS Lambda', 'AWS EKS'],
  },
  {
    title: 'Infrastructure as Code',
    icon: Code,
    skills: ['Terraform', 'Ansible'],
  },
  {
    title: 'Container & Orchestration',
    icon: Server,
    skills: ['Docker', 'Kubernetes', 'AWS EKS'],
  },
  {
    title: 'CI/CD Tools',
    icon: GitBranch,
    skills: ['Jenkins', 'GitHub Actions'],
  },
  {
    title: 'Monitoring & Observability',
    icon: Database,
    skills: ['Prometheus', 'Grafana', 'CloudWatch'],
  },
  {
    title: 'Programming & Scripting',
    icon: Terminal,
    skills: ['Python', 'Bash', 'YAML', 'Linux Shell Scripting'],
  },
  {
    title: 'Databases',
    icon: Database,
    skills: ['MySQL', 'MongoDB'],
  },
  {
    title: 'Version Control',
    icon: GitBranch,
    skills: ['Git', 'GitHub', 'GitLab'],
  },
];

const devOpsPractices = [
  'Continuous Integration',
  'Continuous Deployment',
  'Automation',
  'Infrastructure Monitoring',
  'Scalability',
  'High Availability',
];

export default function SkillsSection() {
  return (
    <section id="skills" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-7xl mx-auto w-full">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-4 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
          Skills & Technologies
        </h2>
        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          My technical toolkit for building reliable cloud infrastructure and automation solutions
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {skillCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <Card
                key={index}
                className="bg-card/40 backdrop-blur-sm border-card-border p-6 hover-elevate transition-all duration-300"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-primary/20 rounded-lg">
                    <Icon size={24} className="text-cyan-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground" data-testid={`text-category-${index}`}>
                    {category.title}
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, skillIndex) => (
                    <Badge
                      key={skillIndex}
                      variant="secondary"
                      className="bg-accent/20 text-accent-foreground border-accent/30"
                      data-testid={`badge-skill-${index}-${skillIndex}`}
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>

        <Card className="bg-card/40 backdrop-blur-sm border-card-border p-6 sm:p-8">
          <h3 className="text-2xl font-bold text-center text-cyan-400 mb-6">DevOps Best Practices</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {devOpsPractices.map((practice, index) => (
              <Badge
                key={index}
                className="bg-primary/20 text-primary-foreground border-primary/40 px-4 py-2 text-sm"
                data-testid={`badge-practice-${index}`}
              >
                {practice}
              </Badge>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
}
