import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Github, ExternalLink } from 'lucide-react';

interface ProjectCardProps {
  title: string;
  description: string;
  tech: string[];
  github: string;
  demo?: string;
  icon: string;
}

export default function ProjectCard({ title, description, tech, github, demo, icon }: ProjectCardProps) {
  return (
    <Card className="bg-card/40 backdrop-blur-sm border-card-border hover-elevate active-elevate-2 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/10 overflow-visible">
      <div className="p-6 space-y-4">
        <div className="flex items-start gap-4">
          <div className="text-5xl" data-testid="text-project-icon">{icon}</div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-cyan-400 mb-2" data-testid="text-project-title">{title}</h3>
          </div>
        </div>

        <p className="text-sm text-card-foreground leading-relaxed" data-testid="text-project-description">
          {description}
        </p>

        <div className="flex flex-wrap gap-2">
          {tech.map((item, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="bg-primary/10 text-primary-foreground border-primary/30 text-xs"
              data-testid={`badge-tech-${index}`}
            >
              {item}
            </Badge>
          ))}
        </div>

        <div className="flex gap-3 pt-2">
          <a href={github} target="_blank" rel="noopener noreferrer" className="flex-1">
            <Button variant="outline" className="w-full gap-2" data-testid="button-github">
              <Github size={16} />
              GitHub
            </Button>
          </a>
          {demo && (
            <a href={demo} target="_blank" rel="noopener noreferrer" className="flex-1">
              <Button className="w-full gap-2" data-testid="button-demo">
                <ExternalLink size={16} />
                Demo
              </Button>
            </a>
          )}
        </div>
      </div>
    </Card>
  );
}
