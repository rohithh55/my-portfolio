import { useState, useEffect } from 'react';
import { Github, Linkedin, Mail, Download, ArrowDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroImage from '@assets/generated_images/DevOps_cloud_infrastructure_hero_8db0f64b.png';

const roles = ['DevOps Engineer', 'Cloud Architect', 'Automation Specialist'];

export default function HeroSection() {
  const [currentRole, setCurrentRole] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const role = roles[currentRole];
    const timeout = setTimeout(() => {
      if (!isDeleting) {
        if (displayText.length < role.length) {
          setDisplayText(role.slice(0, displayText.length + 1));
        } else {
          setTimeout(() => setIsDeleting(true), 2000);
        }
      } else {
        if (displayText.length > 0) {
          setDisplayText(displayText.slice(0, -1));
        } else {
          setIsDeleting(false);
          setCurrentRole((prev) => (prev + 1) % roles.length);
        }
      }
    }, isDeleting ? 50 : 100);

    return () => clearTimeout(timeout);
  }, [displayText, isDeleting, currentRole]);

  const scrollToProjects = () => {
    console.log('Scroll to projects');
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center px-4 pt-20">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-8 md:gap-12 items-center w-full">
        <div className="space-y-6 animate-fade-in">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
            Hi, I'm{' '}
            <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
              Rohith Reddy
            </span>
          </h1>
          
          <div className="h-12 sm:h-14 md:h-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl text-cyan-300 font-semibold">
              {displayText}
              <span className="animate-blink">|</span>
            </h2>
          </div>

          <p className="text-base sm:text-lg text-muted-foreground max-w-2xl">
            DevOps and Cloud enthusiast with hands-on experience in designing scalable cloud infrastructure across AWS. 
            Proficient in containerization, Infrastructure as Code, and CI/CD pipeline implementation.
          </p>

          <div className="flex flex-wrap gap-4">
            <a href="https://github.com/rohithh5" target="_blank" rel="noopener noreferrer">
              <Button size="icon" className="rounded-full" data-testid="button-github">
                <Github size={20} />
              </Button>
            </a>
            <a href="https://www.linkedin.com/in/rohithreddyhh" target="_blank" rel="noopener noreferrer">
              <Button size="icon" className="rounded-full" data-testid="button-linkedin">
                <Linkedin size={20} />
              </Button>
            </a>
            <a href="mailto:rohiithh5@gmail.com">
              <Button size="icon" className="rounded-full" data-testid="button-email">
                <Mail size={20} />
              </Button>
            </a>
          </div>

          <div className="flex flex-wrap gap-4">
            <a href="/Rohith_Reddy_Resume.pdf" download>
              <Button className="rounded-lg gap-2" data-testid="button-resume">
                <Download size={18} />
                Download Resume
              </Button>
            </a>
            <Button variant="outline" className="rounded-lg gap-2" onClick={scrollToProjects} data-testid="button-view-projects">
              View Projects
              <ArrowDown size={18} />
            </Button>
          </div>
        </div>

        <div className="flex justify-center items-center animate-float">
          <img
            src={heroImage}
            alt="DevOps Cloud Infrastructure"
            className="w-full max-w-lg drop-shadow-2xl"
          />
        </div>
      </div>
    </section>
  );
}
